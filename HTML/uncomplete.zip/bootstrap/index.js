$(document).ready(function() {
    $('.card').addClass('animate');
  });
  